package org.wso2.esb.sample;

import org.apache.synapse.MessageContext;
import org.apache.synapse.mediators.AbstractMediator;


public class CustomRegistryMediator extends AbstractMediator {

    String resouceValue;
    String resourcePath;
    String action;

    public boolean mediate(MessageContext messageContext) {

        if (!action.equals(null) && !action.equals("")
                && !resourcePath.equals(null) && !resourcePath.equals("")) {
            if (action.equals("save")) {
                messageContext.getConfiguration().getRegistry()
                        .newResource(resourcePath, false);
                messageContext
                        .getConfiguration()
                        .getRegistry()
                        .updateResource(
                                resourcePath,
                                resouceValue.getBytes());
            } else if (action.equals("delete")) {
                messageContext.getConfiguration().getRegistry()
                        .delete(resourcePath);
            } else if (action.equals("update")) {
                messageContext
                        .getConfiguration()
                        .getRegistry()
                        .updateResource(
                                resourcePath,
                                resouceValue.toString().getBytes());
            }
        }
        return true;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getResourcePath() {
        return resourcePath;
    }

    public void setResourcePath(String resourcePath) {
        this.resourcePath = resourcePath;
    }

    public String getResouceValue() {
        return resouceValue;
    }

    public void setResouceValue(String resouceValue) {
        this.resouceValue = resouceValue;
    }
}
